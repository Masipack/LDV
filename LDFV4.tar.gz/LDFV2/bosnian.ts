<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bs_BA" sourcelanguage="pt_BR">
<context>
    <name>ConfigDataBase</name>
    <message>
        <location filename="interface/configdatabase.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="69"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="116"/>
        <source>Nome</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="163"/>
        <source>Usuário</source>
        <translation>korisnik</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="210"/>
        <source>Senha</source>
        <translation>lozinku</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="257"/>
        <source>Porta</source>
        <translation>Vrata</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="304"/>
        <source>Tabela</source>
        <translation>Tabela</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="351"/>
        <source>Chave Pesquisa</source>
        <translation>Ključ za pretragu</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="426"/>
        <source>Salvar</source>
        <translation>Spremi</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.ui" line="473"/>
        <source>Cancelar</source>
        <translation>Otkaži</translation>
    </message>
    <message>
        <location filename="interface/configdatabase.cpp" line="96"/>
        <source>Configurando parâmetros de acesso ao banco de dados</source>
        <translation>Konfiguriranje pristupnih parametara baze podataka</translation>
    </message>
</context>
<context>
    <name>DialogPart11</name>
    <message>
        <location filename="util/dialogpart11.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.ui" line="62"/>
        <source>FDA 21 CFR Part 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.ui" line="121"/>
        <source>Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.ui" line="200"/>
        <source>Senha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.ui" line="295"/>
        <source>Comentários</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.ui" line="427"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.ui" line="491"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.cpp" line="110"/>
        <source>Usuário ou senha inválido:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dialogpart11.cpp" line="111"/>
        <source>Usuário ou senha inválido</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgDataBase</name>
    <message>
        <location filename="util/dlgDataBase.ui" line="17"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgDataBase.ui" line="85"/>
        <source>Sincronizar com Banco de dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgDataBase.ui" line="132"/>
        <source>Lote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgDataBase.ui" line="205"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgDataBase.ui" line="261"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgDateTime</name>
    <message>
        <location filename="interface/dlgdatetime.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.ui" line="92"/>
        <location filename="interface/dlgdatetime.cpp" line="14"/>
        <source>JANEIRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.ui" line="193"/>
        <source>Hora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.ui" line="284"/>
        <location filename="interface/dlgdatetime.ui" line="463"/>
        <location filename="interface/dlgdatetime.ui" line="642"/>
        <source>00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.ui" line="372"/>
        <source>Minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.ui" line="551"/>
        <source>Segundo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.ui" line="755"/>
        <source>Aceitar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.ui" line="815"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="14"/>
        <source>FEVEREIRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="14"/>
        <source>MARÇO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="15"/>
        <source>ABRIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="15"/>
        <source>MAIO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="15"/>
        <source>JUNHO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="16"/>
        <source>JULHO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="16"/>
        <source>AGOSTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="16"/>
        <source>SETEMBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="17"/>
        <source>OUTRUBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="17"/>
        <source>NOVEMBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlgdatetime.cpp" line="17"/>
        <source>DEZEMBRO</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgInfo</name>
    <message>
        <location filename="util/dlginfo.ui" line="17"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfo.ui" line="98"/>
        <source> Inspection System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfo.ui" line="204"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfo.ui" line="249"/>
        <location filename="util/dlginfo.cpp" line="46"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfo.ui" line="305"/>
        <location filename="util/dlginfo.cpp" line="47"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfo.cpp" line="41"/>
        <source>Sim</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfo.cpp" line="42"/>
        <source>Não</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgInspType</name>
    <message>
        <location filename="interface/dlginsptype.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlginsptype.ui" line="314"/>
        <source>Nome da leitura:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlginsptype.ui" line="395"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/dlginsptype.ui" line="454"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgKeyboard</name>
    <message>
        <location filename="util/dlgkeyboard.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgkeyboard.ui" line="49"/>
        <source>ESC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgkeyboard.ui" line="161"/>
        <source>ENTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgkeyboard.ui" line="217"/>
        <source>CAPS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlgkeyboard.ui" line="303"/>
        <source>SPACE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormAlarms</name>
    <message>
        <location filename="interface/formalarms.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.ui" line="57"/>
        <location filename="interface/formalarms.cpp" line="47"/>
        <source>Alarmes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.ui" line="92"/>
        <source>Log de Eventos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.ui" line="165"/>
        <source>Retornar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.ui" line="218"/>
        <source>Resetar
Alarmes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.ui" line="354"/>
        <location filename="interface/formalarms.cpp" line="17"/>
        <source>JANEIRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="17"/>
        <source>FEVEREIRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="17"/>
        <source>MARÇO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="18"/>
        <source>ABRIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="18"/>
        <source>MAIO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="18"/>
        <source>JUNHO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="19"/>
        <source>JULHO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="19"/>
        <source>AGOSTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="19"/>
        <source>SETEMBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="20"/>
        <source>OUTUBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="20"/>
        <source>NOVEMBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="20"/>
        <source>DEZEMBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formalarms.cpp" line="93"/>
        <source>Reset de alarmes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormConfig</name>
    <message>
        <location filename="interface/formconfig.cpp" line="39"/>
        <source>Configurações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formconfig.cpp" line="74"/>
        <source>Horário de sistema alterado de </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formconfig.cpp" line="74"/>
        <location filename="interface/formconfig.cpp" line="129"/>
        <source> para </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formconfig.cpp" line="129"/>
        <source>Data do sistema alterado de </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formconfig.cpp" line="284"/>
        <source>Alterando configurações  do banco de dados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormConfigH</name>
    <message>
        <location filename="interface/form_configH.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="79"/>
        <source>Alterar hora:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="100"/>
        <source>HORA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="121"/>
        <location filename="interface/form_configH.ui" line="276"/>
        <location filename="interface/form_configH.ui" line="568"/>
        <location filename="interface/form_configH.ui" line="720"/>
        <location filename="interface/form_configH.ui" line="872"/>
        <source>00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="255"/>
        <source>MINUTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="436"/>
        <location filename="interface/form_configH.ui" line="1032"/>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="529"/>
        <source>Alterar data:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="547"/>
        <source>ANO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="699"/>
        <source>MÊS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="851"/>
        <source>DIA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="1138"/>
        <source>Menu
Principal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="1190"/>
        <source>Gerenciamento
de Usuários</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configH.ui" line="1239"/>
        <source>Gerenciamento
Banco de Dados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormConfigV</name>
    <message>
        <location filename="interface/form_configV.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="79"/>
        <source>Alterar hora:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="100"/>
        <source>HORA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="121"/>
        <location filename="interface/form_configV.ui" line="276"/>
        <location filename="interface/form_configV.ui" line="568"/>
        <location filename="interface/form_configV.ui" line="720"/>
        <location filename="interface/form_configV.ui" line="872"/>
        <source>00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="255"/>
        <source>MINUTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="436"/>
        <location filename="interface/form_configV.ui" line="1032"/>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="529"/>
        <source>Alterar data:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="547"/>
        <source>ANO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="699"/>
        <source>MÊS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="851"/>
        <source>DIA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="1138"/>
        <source>Menu
Principal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_configV.ui" line="1190"/>
        <source>Gerenciamento
de Usuários</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormImageLog</name>
    <message>
        <location filename="interface/formimagelog.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formimagelog.ui" line="81"/>
        <source>Voltar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formimagelog.ui" line="145"/>
        <source>Anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formimagelog.ui" line="183"/>
        <source>Posiçao
na fila:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formimagelog.ui" line="202"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormLogin</name>
    <message>
        <location filename="interface/form_login.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.ui" line="93"/>
        <source>Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.ui" line="199"/>
        <source>Senha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.ui" line="349"/>
        <source>Retornar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.ui" line="406"/>
        <source>Efetuar
Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.ui" line="464"/>
        <source>Efetuar
Logoff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.cpp" line="95"/>
        <source>Campos Inválidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.cpp" line="119"/>
        <source>Login de usuario:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.cpp" line="132"/>
        <source>Usuário ou senha inválido (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.cpp" line="135"/>
        <source>Login de usuario INVALIDO:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.cpp" line="145"/>
        <source>Login de usuario DESATIVADO:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.cpp" line="150"/>
        <source>Usuário %1 desativado por excesso de tentativas de login (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_login.cpp" line="165"/>
        <source>Logoff de usuario:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormMainMenuH</name>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="43"/>
        <source>Alarmes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="91"/>
        <source>Produtos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="139"/>
        <source>Impressora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="187"/>
        <source>Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="235"/>
        <source>Exportar
Receitas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="284"/>
        <source>Relatório
Part 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_mainmenuH.ui" line="333"/>
        <source>Versão de
Software</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormNewProduct</name>
    <message>
        <location filename="interface/formnewproduct.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproduct.ui" line="57"/>
        <source>Câmera
Anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproduct.ui" line="106"/>
        <location filename="interface/formnewproduct.cpp" line="65"/>
        <location filename="interface/formnewproduct.cpp" line="156"/>
        <source>Próxima
Câmera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproduct.ui" line="152"/>
        <source>Impressora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproduct.ui" line="213"/>
        <source>Voltar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproduct.cpp" line="63"/>
        <location filename="interface/formnewproduct.cpp" line="140"/>
        <location filename="interface/formnewproduct.cpp" line="190"/>
        <source>Finalizar
Receita</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormNewProductContent</name>
    <message>
        <location filename="interface/formnewproductcontent.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproductcontent.ui" line="465"/>
        <source>Inspeções:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproductcontent.cpp" line="112"/>
        <source>Nova Inspeção (Câmera </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormNewProductFinish</name>
    <message>
        <location filename="interface/formnewproductfinish.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproductfinish.ui" line="69"/>
        <source>Nome da Receita:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproductfinish.ui" line="158"/>
        <source>Gravar
Receita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formnewproductfinish.cpp" line="39"/>
        <source>Nova Inspeção (Finalizar Receita)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormNewUser</name>
    <message>
        <location filename="interface/form_newuser.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="63"/>
        <source>Senha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="78"/>
        <source>Nome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="121"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="136"/>
        <source>Usuário ativo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="179"/>
        <source>Confirmar Senha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="225"/>
        <source>Privilégios de acesso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="422"/>
        <location filename="interface/form_newuser.cpp" line="21"/>
        <source>OPERADOR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="541"/>
        <source>Criar
Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.ui" line="602"/>
        <source>Retornar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="21"/>
        <source>SUPERVISOR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="21"/>
        <source>ADMINISTRADOR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="53"/>
        <source>Gravar
Alteração</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="97"/>
        <source>Editar Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="98"/>
        <source>Gravar
Alterações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="102"/>
        <source>Novo Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="103"/>
        <source>Adicionar
Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="175"/>
        <source>Login inválido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="183"/>
        <source>Senha inválida !
A senha deve ter 4 ou mais caracteres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="191"/>
        <source>Senha inválida !
A senha digitada deve coincidir nos dois campos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="204"/>
        <location filename="interface/form_newuser.cpp" line="212"/>
        <source>Erro ao executar operação COD:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_newuser.cpp" line="220"/>
        <source>Usuário já cadastrado.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormPart11</name>
    <message>
        <location filename="interface/formpart11.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="72"/>
        <source>FDA 21 CFR Part 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="120"/>
        <location filename="interface/formpart11.ui" line="182"/>
        <source>Lote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="125"/>
        <source>Data/Hora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="130"/>
        <location filename="interface/formpart11.ui" line="269"/>
        <source>Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="135"/>
        <location filename="interface/formpart11.ui" line="359"/>
        <source>Equipamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="140"/>
        <source>Descrição</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="145"/>
        <source>Comentário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="452"/>
        <source>A partir de:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="484"/>
        <source>01/01/2000 00:00:00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="539"/>
        <source>Até:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="571"/>
        <source>31/12/2100 23:59:59</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="638"/>
        <source>Retornar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="699"/>
        <source>Exportar PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="774"/>
        <source>Limpar
Filtros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.ui" line="839"/>
        <source>Filtrar
Resultados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.cpp" line="297"/>
        <source>Insira Drive USB !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formpart11.cpp" line="306"/>
        <source>Falha criando pasta em drive usb</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormPrinter</name>
    <message>
        <location filename="interface/formprinter.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprinter.ui" line="85"/>
        <source>Retornar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormProcess</name>
    <message>
        <location filename="interface/formprocess.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.ui" line="42"/>
        <source>Câmera
Anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.ui" line="91"/>
        <source>Próxima
Câmera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.ui" line="137"/>
        <source>Impressora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.ui" line="198"/>
        <source>Voltar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.cpp" line="152"/>
        <source>Deseja interromper a inspeção ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.cpp" line="156"/>
        <source>Inspeção interrompida:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.cpp" line="193"/>
        <source>Gravar alterações na receita?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocess.cpp" line="199"/>
        <source>Atributos de inspeção alterados:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormProcessContent</name>
    <message>
        <location filename="interface/formprocesscontent.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocesscontent.ui" line="457"/>
        <source>Inspeções:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocesscontent.ui" line="543"/>
        <source>Estatística</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocesscontent.ui" line="576"/>
        <source>Imagens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocesscontent.cpp" line="56"/>
        <source>Inspeção (Câmera </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formprocesscontent.cpp" line="366"/>
        <source>Alterando atributes na receita</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormProducts</name>
    <message>
        <location filename="interface/formproducts.cpp" line="115"/>
        <source>Formato excluido:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formproducts.cpp" line="127"/>
        <source>Iniciada criação de receita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formproducts.cpp" line="155"/>
        <source>Receita carregada:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormProductsH</name>
    <message>
        <location filename="interface/form_productsH.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsH.ui" line="180"/>
        <source>Lote:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsH.ui" line="265"/>
        <source>Menu
Principal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsH.ui" line="310"/>
        <source>Carregar
Inspeção</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsH.ui" line="355"/>
        <source>Nova
Inspeção</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsH.ui" line="400"/>
        <source>Excluir
Inspeção</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormProductsV</name>
    <message>
        <location filename="interface/form_productsV.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsV.ui" line="186"/>
        <source>Lote:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsV.ui" line="271"/>
        <source>Menu
Principal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsV.ui" line="316"/>
        <source>Carregar
Inspeção</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsV.ui" line="361"/>
        <source>Nova
Inspeção</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_productsV.ui" line="406"/>
        <source>Excluir
Inspeção</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormStatistics</name>
    <message>
        <location filename="interface/formstatistics.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formstatistics.ui" line="22"/>
        <source>Inspeções</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formstatistics.ui" line="51"/>
        <location filename="interface/formstatistics.ui" line="94"/>
        <location filename="interface/formstatistics.ui" line="137"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formstatistics.ui" line="65"/>
        <source>Aprovados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formstatistics.ui" line="108"/>
        <source>Reprovados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formstatistics.ui" line="161"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formstatistics.cpp" line="54"/>
        <source>Apagando estatistica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormUsbExport</name>
    <message>
        <location filename="interface/formusbexport.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="40"/>
        <source>Receitas no Sistema:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="138"/>
        <source>EXPORTAR todas as
receitas SISTEMA -&gt; USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="199"/>
        <source>IMPORTAR receita
USB -&gt; SISTEMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="260"/>
        <source>EXPORTAR receita
SISTEMA -&gt; USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="321"/>
        <source>IMPORTAR configurações
USB -&gt; SISTEMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="382"/>
        <source>EXPORTAR configurações
SISTEMA -&gt; USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="438"/>
        <source>Receitas no drive USB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.ui" line="513"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="43"/>
        <source>Drive USB: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="43"/>
        <source> livres)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="54"/>
        <source>Insira Drive USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="70"/>
        <source>Imp. e Exportar Dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="101"/>
        <source>Selecione uma receita (USB) para importar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="111"/>
        <source>ATENÇÃO
Já existe um arquivo com o mesmo
nome no sistema.

 Deseja sobrescrever este arquivo?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="115"/>
        <source>Falha excluindo arquivo local para copia USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="122"/>
        <source>Importação USB de receita:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="126"/>
        <source>Falha copiando arquivo de drive USB para o sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="129"/>
        <source>Arquivo copiado USB-&gt;SISTEMA:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="145"/>
        <source>Selecione uma receita (Sistema) para exportar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="154"/>
        <location filename="interface/formusbexport.cpp" line="327"/>
        <source>Falha criando pasta em drive usb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="164"/>
        <location filename="interface/formusbexport.cpp" line="341"/>
        <source>Já existe um arquivo com o mesmo
nome no drive USB.

 Deseja sobrescrever este arquivo?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="168"/>
        <location filename="interface/formusbexport.cpp" line="345"/>
        <source>Falha excluindo arquivo USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="175"/>
        <location filename="interface/formusbexport.cpp" line="352"/>
        <source>Exportação USB de receita:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="179"/>
        <location filename="interface/formusbexport.cpp" line="356"/>
        <source>Falha copiando arquivo para drive USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="182"/>
        <location filename="interface/formusbexport.cpp" line="359"/>
        <source>Arquivo copiado SISTEMA-&gt;USB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="200"/>
        <source>Importação USB de configurações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="209"/>
        <source>Já existe um arquivo com o mesmo
nome </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="209"/>
        <source> no SISTEMA.

 Deseja sobrescrever este arquivo?
&gt;&gt; ESTA OPERACAO PODE CORROMPER O SISTEMA &lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="215"/>
        <source>Falha excluindo arquivo (BKP) SISTEMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="216"/>
        <location filename="interface/formusbexport.cpp" line="228"/>
        <location filename="interface/formusbexport.cpp" line="289"/>
        <location filename="interface/formusbexport.cpp" line="300"/>
        <source>Falha copiando o arquivo </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="226"/>
        <location filename="interface/formusbexport.cpp" line="298"/>
        <source>Falha copiando arquivo </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="226"/>
        <source> para SISTEMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="233"/>
        <source>Arquivo copiado USB-&gt;SISTEMA: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="248"/>
        <source>Falha criando pasta em drive usb (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="266"/>
        <source>Exportação USB de configurações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="278"/>
        <source>Já existem configurações no drive USB.
Deseja sobrescrever estes arquivos?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="286"/>
        <source>Falha excluindo arquivo (BKP) USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="298"/>
        <source> para drive USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="305"/>
        <source>Arquivo copiado SISTEMA-&gt;USB: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="311"/>
        <source>Arquivos transferidos com sucesso !

Pasta USB:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/formusbexport.cpp" line="332"/>
        <source>Exportação USB de todas as receitas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormUsers</name>
    <message>
        <location filename="interface/form_users.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.ui" line="82"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.ui" line="126"/>
        <source>Novo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.ui" line="170"/>
        <source>Editar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.ui" line="214"/>
        <source>Excluir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.ui" line="258"/>
        <source>Exibir
Inativos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.cpp" line="116"/>
        <location filename="interface/form_users.cpp" line="126"/>
        <location filename="interface/form_users.cpp" line="149"/>
        <source>Selecione um usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.cpp" line="158"/>
        <source>Deseja excluir usuário %1 ( %2 ) ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.cpp" line="166"/>
        <source>Erro ao executar operação COD:%1
%2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormVersion</name>
    <message>
        <location filename="interface/formversion.cpp" line="38"/>
        <source>Versão de Software</source>
        <translation>Vrsion tgsrev</translation>
    </message>
</context>
<context>
    <name>FormVersionH</name>
    <message>
        <location filename="interface/form_versionH.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="interface/form_versionH.ui" line="34"/>
        <source>Menu
Principal</source>
        <translation>Meni
Glavni</translation>
    </message>
    <message>
        <location filename="interface/form_versionH.ui" line="113"/>
        <source>Pedido:</source>
        <translation>Naredba:</translation>
    </message>
    <message>
        <location filename="interface/form_versionH.ui" line="173"/>
        <source>Modelo:</source>
        <translation>Model:</translation>
    </message>
    <message>
        <location filename="interface/form_versionH.ui" line="233"/>
        <source>Versão:</source>
        <translation>Verzija:</translation>
    </message>
    <message>
        <location filename="interface/form_versionH.ui" line="293"/>
        <source>Firmware:</source>
        <translation>Firmware:</translation>
    </message>
    <message>
        <location filename="interface/form_versionH.ui" line="353"/>
        <source>Câmera:</source>
        <translation>Kamera:</translation>
    </message>
</context>
<context>
    <name>FormVersionV</name>
    <message>
        <location filename="interface/form_versionV.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_versionV.ui" line="54"/>
        <source>Modelo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_versionV.ui" line="75"/>
        <location filename="interface/form_versionV.ui" line="114"/>
        <location filename="interface/form_versionV.ui" line="153"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_versionV.ui" line="93"/>
        <source>Versão:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_versionV.ui" line="132"/>
        <source>Pedido:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_versionV.ui" line="203"/>
        <source>Menu
Principal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MVListWidget</name>
    <message>
        <location filename="interface/widgets/mvlistwidget.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainDialog</name>
    <message>
        <location filename="maindialog.ui" line="14"/>
        <source>MainDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maindialog.ui" line="121"/>
        <location filename="maindialog.ui" line="139"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maindialog.ui" line="176"/>
        <source>Menu Nome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maindialog.ui" line="213"/>
        <source>SISTEMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maindialog.ui" line="231"/>
        <source>Efetuar Login</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MvBarcode</name>
    <message>
        <location filename="mv/tools/mvbarcode.cpp" line="119"/>
        <location filename="mv/tools/mvbarcode.cpp" line="191"/>
        <source>Não detectado! em </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MvCamera</name>
    <message>
        <location filename="mv/camera/mvcamera.cpp" line="57"/>
        <location filename="mv/camera/mvcamera.cpp" line="90"/>
        <location filename="mv/camera/mvcamera.cpp" line="121"/>
        <location filename="mv/camera/mvcamera.cpp" line="152"/>
        <source>ERRO: parametro inexistente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mv/camera/mvcamera.cpp" line="65"/>
        <location filename="mv/camera/mvcamera.cpp" line="98"/>
        <location filename="mv/camera/mvcamera.cpp" line="160"/>
        <source>Atencao: parametro inacessivel: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mv/camera/mvcamera.cpp" line="129"/>
        <source>Atencao: parametro inacessivel: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MvDataMatrix</name>
    <message>
        <location filename="mv/tools/mvdatamatrix.cpp" line="131"/>
        <source>Não detectado! em </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MvOCR</name>
    <message>
        <location filename="mv/tools/mvocr.cpp" line="63"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mv/tools/mvocr.cpp" line="97"/>
        <source>Não detectado! em </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamsBarcode</name>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="99"/>
        <source>Visível</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="163"/>
        <source>Exibir Resultado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="227"/>
        <source>Ângulo Fixo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="291"/>
        <source>PharmaCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="355"/>
        <source>Sentido
Pharmacode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="421"/>
        <source>Dados Esperados:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="460"/>
        <source>Copiar Dados Extraídos para Dados Esperados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsbarcode.ui" line="484"/>
        <source>Dados Extraídos:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamsDataMatrix</name>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="99"/>
        <source>Visível</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="163"/>
        <source>Ângulo Fixo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="224"/>
        <source>Dados Esperados:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="263"/>
        <source>Copiar Dados Extraídos para Dados Esperados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="287"/>
        <source>Dados Extraídos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="351"/>
        <source>Ajuste de Contraste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsdatamatrix.ui" line="449"/>
        <source>nenhum</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamsFiducial</name>
    <message>
        <location filename="interface/widgets/paramsfiducial.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsfiducial.ui" line="99"/>
        <source>Visível</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsfiducial.ui" line="163"/>
        <source>Ângulo Fixo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsfiducial.ui" line="226"/>
        <source>Similaridade Mínima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsfiducial.ui" line="324"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsfiducial.ui" line="420"/>
        <source>Região Mínima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsfiducial.ui" line="518"/>
        <source>5%</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamsOCR</name>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="99"/>
        <source>Visível</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="163"/>
        <source>Exibir Resultado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="227"/>
        <source>Ângulo Fixo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="288"/>
        <source>Dados Esperados:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="340"/>
        <source>Copiar Dados Extraídos para Dados Esperados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="371"/>
        <source>Banco de Dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="411"/>
        <source>Dados Extraídos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="452"/>
        <source>Correção de falhas na impressão:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/widgets/paramsocr.ui" line="550"/>
        <source>Não Aplicado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PdfMaker</name>
    <message>
        <location filename="util/pdfmaker.cpp" line="33"/>
        <source>Deseja sobrescrever &apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="45"/>
        <source>Erro ao gerar arquivo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="129"/>
        <source>Lote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="129"/>
        <source>Data/Hora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="129"/>
        <source>Usuário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="129"/>
        <source>Equipamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="129"/>
        <source>Descrição</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="129"/>
        <source>Comentário</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/pdfmaker.cpp" line="252"/>
        <source>Relatório CFR21 - Part11</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="interface/form_users.cpp" line="34"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.cpp" line="35"/>
        <source>Nome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.cpp" line="36"/>
        <source>Nível</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/form_users.cpp" line="37"/>
        <source>Ativo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="49"/>
        <location filename="main.cpp" line="54"/>
        <source>ERRO FATAL: ARQUIVO DE CONFIGURACOES NAO ENCONTRADO. VERIFIQUE A INSTALACAO DO SISTEMA, SISTEMA DESLIGANDO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="68"/>
        <source> --------- Sistema Inicializando --------- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="80"/>
        <source>Arquivo de estilos nao encontrado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="88"/>
        <source>Arquivo de estilos corrompido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="116"/>
        <source>Porta serial </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="116"/>
        <source> indisponivel para uso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="153"/>
        <source>Arquivo de dados PART11 nao encontrado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="164"/>
        <source>Arquivo de dados do sistema nao encontrado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="175"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="265"/>
        <source>Inicializando Sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="271"/>
        <source> --------- Sistema Desligando --------- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mv/tools/mvdatamatrix.cpp" line="282"/>
        <source>INFO       : %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mv/tools/mvdatamatrix.cpp" line="285"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="288"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="291"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="294"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="297"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="300"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="303"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="306"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="332"/>
        <location filename="mv/tools/mvdatamatrix.cpp" line="339"/>
        <source>ERRO FATAL: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/fileutil.h" line="37"/>
        <location filename="util/fileutil.h" line="60"/>
        <source>Formato existente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/fileutil.h" line="48"/>
        <location filename="util/fileutil.h" line="71"/>
        <source>Erro gravando formato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/fileutil.h" line="84"/>
        <location filename="util/fileutil.h" line="109"/>
        <location filename="util/fileutil.h" line="133"/>
        <source>Formato não encontrado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/fileutil.h" line="96"/>
        <location filename="util/fileutil.h" line="121"/>
        <location filename="util/fileutil.h" line="145"/>
        <source>Erro lendo formato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/systemsettings.h" line="102"/>
        <location filename="util/systemsettings.h" line="117"/>
        <source>WARNING: configuration </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/systemsettings.h" line="104"/>
        <location filename="util/systemsettings.h" line="119"/>
        <source> not found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WindowManager</name>
    <message>
        <location filename="interface/windowmanager.cpp" line="62"/>
        <source>OPERADOR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/windowmanager.cpp" line="62"/>
        <source>SUPERVISOR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/windowmanager.cpp" line="62"/>
        <source>ADMINISTRADOR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/windowmanager.cpp" line="139"/>
        <source>Logoff automático de usuario:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="interface/windowmanager.cpp" line="311"/>
        <source>Efetuar Login</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgInfoProcess</name>
    <message>
        <location filename="util/dlginfoprocess.ui" line="17"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfoprocess.ui" line="86"/>
        <source> Inspection System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="util/dlginfoprocess.ui" line="192"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
