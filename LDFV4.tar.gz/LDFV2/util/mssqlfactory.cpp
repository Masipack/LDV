#include "mssqlfactory.h"

MSSQLFactory::MSSQLFactory(const DATABASE &database, const QString drive_sql_nam): MvAbstractDataBase(database)
{

}

bool MSSQLFactory::Init()
{

}
